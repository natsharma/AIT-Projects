const express = require('express');
const path = require('path');
const app = express();

app.set('view engine', 'hbs');

const publicPath = path.join(__dirname, 'public');
app.use(express.static(publicPath));
const logger = (req, res, next) => {
  console.log(req.method, req.path, req.query);
  next();
};
app.use(logger);
app.use((req, res, next) => {
  if(req.get('Host')) {
    next();
  } else {
    res.status(400).send('invalid request');
  }
});
app.use(express.urlencoded({extended: false}));

app.get('/', (req, res) => {
  res.send('<h1>nothing to see here folks</h1>');
});

app.get('/form', (req, res) => {
  res.render('form');
});

function hex(c) {
  var h = c.toString(16);
  return h.length == 1 ? "0" + h : h;
}
function rgb(red, green, blue) {
  var red = "#" + hex(red) + hex(green) + hex(blue);
  return red;
}

function generatePalette(num, r, g, b){
  var red = r;
  var green = g;
  var blue = b;
  const colorArray = [];
  for (var i=0; i<num; i++){
    const hexVal = rgb(red, green, blue);
    red = red + 10;
    green = green + 10;
    blue = blue + 10;
    colorArray.push(hexVal);
  }
  return colorArray;
}

app.get('/generate', (req, res) => {
  const red = parseInt(req.query.red);
  const green = parseInt(req.query.green);
  const blue = parseInt(req.query.blue);
  const howMany = parseInt(req.query.howmany);
  const colorPalObj = generatePalette(howMany, red, green, blue);
  res.render('form', {result: Object.values(colorPalObj)});
  // res.status(200).send(isNaN(hexVal) ? 'not a number' : '' + hexVal);
});

app.listen(3000);
