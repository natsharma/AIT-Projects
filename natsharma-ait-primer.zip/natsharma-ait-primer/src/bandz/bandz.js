//bandz.js
const express = require('express');
const path = require('path');
const app = express();

app.set('view engine', 'hbs');

const publicPath = path.join(__dirname, 'public');
app.use(express.static(publicPath));

const logger = (req, res, next) => {
  console.log(req.method, req.path, req.query);
  next();
};

app.use(logger);

app.use((req, res, next) => {
  if(req.get('Host')) {
    next();
  } else {
    res.status(400).send('invalid request');
  }
});

app.use(express.urlencoded({extended: false}));

var bandArray = [];


app.get('/', (req, res) =>{
  res.render('forms', {'recommendations': bandArray});
});

app.post('/', (req, res) => {
  const bandObj = req.body;
  bandArray.push(bandObj);
	res.redirect('/');
});

app.get('/', (req, res) => {
  const filterGenre = req.body;
  bandArray = bandArray.filter(word => word.filterGenre);
  res.redirect('/');
})

app.listen(3000);
